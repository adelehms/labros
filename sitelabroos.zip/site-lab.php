<!DOCTYPE html/>
<html>
    <head>
	
       <link rel="stylesheet" href="sitelab.css"/>
    </head>

        <body>
            <div class="back" style="background:white">
            <img class="pic" src="pic.png"/>

            <div class="sabz" style=" background: #4B6346; border-radius: 12px;">
                <a href="https://www.instagram.com/labros_jewelry/?utm_source=ig_web_button_share_sheet&igshid=OGQ5ZDc2ODk2ZA==">
                     <div class="moraba1" style=" background: rgba(255, 225.50, 203.15, 0.79); border-radius: 7px">
                    <img class="insta" src="insta.png"/></div>
                </a>
                
                <a href="https://t.me/labros_jewelry">
            <div class="moraba2" style=" background: rgba(255, 225.50, 203.15, 0.79); border-radius: 7px">
                <img class="tel" src="tel.png"/></div></a>
                
                <a href="36.32678493634573, 59.536000313731485">
            <div class="moraba3" style=" background: rgba(255, 225.50, 203.15, 0.79); border-radius: 7px">
                <img class="loc" src="loc.png"/></div></a>

            </div>
            </div>

            
            <script src="sitelab.js"></script>
        </body>
</html>